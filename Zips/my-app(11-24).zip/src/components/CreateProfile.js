import React from 'react';

function CreateProfile() {
    return ( 
        <div className="dualBtn bw90">
            <a href="#" className="nextBtnSmall">Create user profile</a>
            <a href="#" className="nextBtnSmall">Existing user profile</a>
        </div>
     );
}

export default CreateProfile;