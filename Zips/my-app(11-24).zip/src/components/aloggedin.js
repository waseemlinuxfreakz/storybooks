import React from 'react';

function AloggedIn() {
    return ( 
        <div className="dualBtn bw90">
            <a href="#" className="nextBtnSmall">Continue as a logged in user</a>
            <a href="#" className="nextBtnSmall">Continue as a logged out user</a>
        </div>
     );
}

export default AloggedIn;